/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tadsb.pi3.livrarianext.servlets;

import br.senac.tadsb.pi3.livrarianext.exceptions.LojaException;
import br.senac.tadsb.pi3.livrarianext.models.Loja;
import br.senac.tadsb.pi3.livrarianext.servicos.ServicoLoja;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Erick
 */
public class ManterLoja extends HttpServlet{
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try
        {            
            ServicoLoja servico = new ServicoLoja();

            String lojaId = request.getParameter("id");

            if (lojaId != null && !lojaId.isEmpty()){
                
                Loja loja = servico.ObterLojaPorId(Integer.parseInt(lojaId));
                
                request.setAttribute("loja", loja);
            }    
        }
        catch(LojaException ue)
        {
            request.setAttribute("erro", ue.getMessage());
        }               

        RequestDispatcher dispatcher = request.getRequestDispatcher("Loja.jsp");        
        
        try
        {
            dispatcher.forward(request, response);
        }
        catch(IOException ex)
        {

        }
    }
    
     /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nome = request.getParameter("nome");
        String cnpj = request.getParameter("cnpj");
        String razaoSocial = request.getParameter("razaoSocial");
        String telefone = request.getParameter("telefone");
        
        
        try
        {
            ServicoLoja servico = new ServicoLoja();
            servico.incluir(nome, cnpj, true, razaoSocial, telefone);
            response.sendRedirect("Lojas");
        }
        catch(LojaException ue)
        {
            
        } catch (Exception ex) {
            
        }
    }
}
