/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tadsb.pi3.livrarianext.servicos;

import br.senac.tadsb.pi3.livrarianext.database.DaoLoja;
import br.senac.tadsb.pi3.livrarianext.enums.ExceptionTypesEnum;
import br.senac.tadsb.pi3.livrarianext.exceptions.LojaException;
import br.senac.tadsb.pi3.livrarianext.models.Loja;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Erick
 */
public class ServicoLoja {
    
    DaoLoja dao;
    
    public ServicoLoja() throws LojaException {
        try
        {
            dao = new DaoLoja();
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.getMessage());
            throw new LojaException(sqlex.getMessage(), ExceptionTypesEnum.DISPLAY);
        }
        catch(Exception ex)
        {
            throw new LojaException("");
        }
    }
    
    public void incluir(String nome, String cnpj, Boolean ativo, String razaoSocial, String telefone) throws LojaException{
        Loja novo = new Loja(nome,cnpj,true,razaoSocial,telefone);
    }
    
    protected void incluir(Loja loja) throws LojaException{
        try
        {
            dao.incluir(loja);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_CRUD);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
    
     public void alterar(int id, String nome, String cnpj, Boolean ativo, String razaoSocial, String telefone) throws LojaException {
        try
        {
            Loja loja = dao.obterPorId(id);
            loja.setNome(nome);
            loja.setCnpj(cnpj);
            loja.setAtivo(ativo);
            loja.setRazaoSocial(razaoSocial);
            loja.setTelefone(telefone);
            this.alterar(loja);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_SELECT);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
    
    protected void alterar(Loja loja) throws LojaException {
        try
        {
            dao.alterar(loja);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_CRUD);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
    
    public void excluir(int id) throws LojaException {
        try
        {
            Loja loja = dao.obterPorId(id);
            this.excluir(loja);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_SELECT);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
    
    protected void excluir(Loja loja) throws LojaException {
        try
        {
            dao.excluir(loja);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_CRUD);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    } 
    
    public List<Loja> ObterLojas(String nome, String cnpj) throws LojaException  {
        try
        {
            return dao.obterLojas(nome, cnpj);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_CRUD);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
    
    public Loja ObterLojaPorId(int id) throws LojaException  {
        try
        {
            return dao.obterPorId(id);
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.SPECIFIC_CRUD);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            throw new LojaException(ExceptionTypesEnum.GENERAL);
        }
    }
}
